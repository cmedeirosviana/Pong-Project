#include "Control.cpp"
#include "Design.cpp"
#include "Paddle.cpp"
#include "Ball.cpp"

int main()
{
    Control control;
    control.play();

    return 0;
}
